ServerEvents.recipes(event => {

    // Market
    event.remove({id: 'farmingforblockheads:market'})
    event.recipes.summoningrituals.altar('malum:sacred_spirit')
        .input(Item.of('minecraft:emerald', 2))
        .input('minecraft:crafting_table')
        .input('minecraft:red_wool')
        .itemOutput('farmingforblockheads:market')

    // might change this
})