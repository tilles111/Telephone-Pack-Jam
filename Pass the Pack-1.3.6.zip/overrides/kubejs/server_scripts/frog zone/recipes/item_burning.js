ServerEvents.recipes(event => {

    // Spirit fire alternate for if you make the fire first
    event.custom(
        {
            "type": "lychee:item_burning",
            "post": [
                {
                    "type": "place",
                    "block": {
                        "blocks": [
                            "occultism:spirit_fire"
                        ]
                    },
                }
            ],
            "item_in": {
                "item": "occultism:datura"
            },
        }
    )

})