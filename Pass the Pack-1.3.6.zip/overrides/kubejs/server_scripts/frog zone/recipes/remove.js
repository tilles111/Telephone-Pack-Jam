ServerEvents.recipes(event => {

    event.remove({id: 'quark:tweaks/crafting/utility/bent/cookie'})
    event.remove({id: 'quark:tweaks/crafting/utility/bent/bread'})

})