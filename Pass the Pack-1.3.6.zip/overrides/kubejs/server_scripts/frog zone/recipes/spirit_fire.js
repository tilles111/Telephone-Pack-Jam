ServerEvents.recipes(event => {

    event.recipes.occultism.spirit_fire('thermal:silver_ingot', '#forge:ingots/lead')

    event.remove({id: 'occultism:spirit_fire/spirit_attuned_gem'})
    event.recipes.occultism.spirit_fire('occultism:spirit_attuned_gem', '#forge:gem_tool_gems')

})