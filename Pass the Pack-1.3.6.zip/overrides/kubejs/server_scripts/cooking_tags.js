ServerEvents.tags('block', event => {

    // frog made this stuff so far

    // Valid trapdoors for Cooking
    event.add('kubejs:cooking_trapdoors', [
        'minecraft:iron_trapdoor',
        'minecraft:crimson_trapdoor',
        'minecraft:warped_trapdoor',
        'supplementaries:netherite_trapdoor',
        'thermal:rubberwood_trapdoor'
    ])

    // Valid blocks for oven
    event.add('kubejs:oven_blocks', [
        'minecraft:mud_bricks',
        'minecraft:bricks',
        'supplementaries:ash_bricks'
    ])

    // Valid pressure plates for oven
    event.add('kubejs:oven_pressure_plates', [
        'minecraft:stone_pressure_plate',
        'minecraft:crimson_pressure_plate',
        'minecraft:warped_pressure_plate',
        'minecraft:polished_blackstone_pressure_plate',
        'minecraft:heavy_weighted_pressure_plate',
        'minecraft:light_weighted_pressure_plate',
        'quark:obsidian_pressure_plate',
        'malum:tainted_rock_pressure_plate',
        'malum:twisted_rock_pressure_plate'
    ])
})