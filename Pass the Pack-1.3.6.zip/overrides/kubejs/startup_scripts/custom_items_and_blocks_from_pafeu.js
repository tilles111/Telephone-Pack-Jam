StartupEvents.registry('item', event => {
    event.create('basic_mortar')
    .maxStackSize(1)
    .maxDamage(64)
    .parentModel("item/handheld")
  })

StartupEvents.registry('block', event => {

    event.create('magma_block_on_cooldown',)
    .textureAll('minecraft:block/magma')
    .unbreakable()//used as a delay for the oven multiblock it gets replaced back with stone pressure plate after 5 seconds
})

