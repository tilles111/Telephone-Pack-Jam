StartupEvents.registry('item', event => {
    event.create('flint_chisel').maxStackSize(1).maxDamage(64).parentModel("item/handheld")
    event.create('rock')
    event.create('gemstone_sword', 'sword').tier('iron')
    event.create('gemstone_pickaxe', 'pickaxe').tier('iron')
    event.create('gemstone_shovel', 'shovel').tier('iron')
    event.create('gemstone_axe', 'axe').tier('iron')
    event.create('gemstone_hoe', 'hoe').tier('iron')
  })