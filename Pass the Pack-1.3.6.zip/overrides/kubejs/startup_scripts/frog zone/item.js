StartupEvents.registry('item', event => {

    event.create('gemstone_chisel').maxStackSize(1).maxDamage(250).parentModel("item/handheld")

})