/// <reference path="./globals.d.ts" />
declare const HOUR: 3600000.0;
declare const global: {"Nuts": {1: null, 2: null, 3: null, 4: null, 0: null}, "Grains": {1: null, 2: null, 3: null, 4: null, 0: null}, "jeiRuntime": Internal.JeiRuntime, "Veggies": {0: null, 1: null, 2: null, 3: null, 4: null, 5: null, 6: null, 7: null, 8: null, 9: null, 10: null, 11: null, 12: null, 13: null, 14: null, 15: null, 16: null, 17: null, 18: null, 19: null, 20: null, 21: null, 22: null, 23: null, 24: null, 25: null, 26: null, 27: null, 28: null, 29: null, 30: null, 31: null, 32: null}, "RawMeat": {1: null, 2: null, 3: null, 4: null, 5: null, 6: null, 7: null, 8: null, 9: null, 10: null, 11: null, 12: null, 13: null, 14: null, 15: null, 16: null, 17: null, 18: null, 19: null, 20: null, 0: null}, "BasicSteamed": {1: null, 2: null, 0: null}, "Fruits": {33: null, 34: null, 35: null, 36: null, 37: null, 38: null, 0: null, 1: null, 2: null, 3: null, 4: null, 5: null, 6: null, 7: null, 8: null, 9: null, 10: null, 11: null, 12: null, 13: null, 14: null, 15: null, 16: null, 17: null, 18: null, 19: null, 20: null, 21: null, 22: null, 23: null, 24: null, 25: null, 26: null, 27: null, 28: null, 29: null, 30: null, 31: null, 32: null}, "CookedMeat": {1: null, 2: null, 3: null, 4: null, 5: null, 6: null, 7: null, 8: null, 9: null, 10: null, 11: null, 12: null, 0: null}, "Cookies": {1: null, 2: null, 0: null}, "BakeGoods": {1: null, 2: null, 3: null, 4: null, 5: null, 0: null}, "Juices": {1: null, 2: null, 3: null, 4: null, 5: null, 6: null, 7: null, 0: null}, "BasicCooking": {1: null, 2: null, 3: null, 4: null, 5: null, 6: null, 7: null, 0: null}, "itemsToRemove": {1: null, 2: null, 3: null, 4: null, 5: null, 6: null, 7: null, 8: null, 9: null, 0: null}};
declare const IngredientHelper: Internal.IngredientForgeHelper;
declare const ForgeModEvents: Internal.ForgeEventWrapper;
declare const Painter: Internal.Painter;
declare const MINUTE: 60000.0;
declare const Client: Internal.Minecraft;
declare const console: Internal.ConsoleJS;
declare const Java: Internal.JavaWrapper;
declare const FTBQuests: Internal.FTBQuestsKubeJSWrapper;
declare const ForgeEvents: Internal.ForgeEventWrapper;
declare const SECOND: 1000.0;
declare const Interval: Internal.IntervalJS;
