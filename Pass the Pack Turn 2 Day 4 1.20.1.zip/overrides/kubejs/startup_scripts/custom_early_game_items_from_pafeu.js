StartupEvents.registry('item', event => {
    event.create('basic_mortar').maxStackSize(1).maxDamage(64).parentModel("item/handheld")
  })