ServerEvents.recipes(event => {
    event.remove({ output: 'minecraft:furnace' })
    event.shaped(
        Item.of('kubejs:chisel', 1),
        [
          ' F',
          'S '
        ],
        {
          F: 'minecraft:flint',
          S: 'minecraft:stick'
        }
      )
    event.shaped(
        Item.of('kubejs:gemstone_sword', 1),
        [
          'G',
          'G',
          'S'
        ],
        {
          G: '#forge:gem_tool_gems',
          S: 'minecraft:stick'
        }
      )
    event.shaped(
        Item.of('kubejs:gemstone_pickaxe', 1),
        [
          'GGG',
          ' S ',
          ' S '
        ],
        {
          G: '#forge:gem_tool_gems',
          S: 'minecraft:stick'
        }
      )
    event.shaped(
        Item.of('kubejs:gemstone_shovel', 1),
        [
          'G',
          'S',
          'S'
        ],
        {
          G: '#forge:gem_tool_gems',
          S: 'minecraft:stick'
        }
      )
    event.shaped(
        Item.of('kubejs:gemstone_axe', 1),
        [
          'GG',
          'GS',
          ' S'
        ],
        {
          G: '#forge:gem_tool_gems',
          S: 'minecraft:stick'
        }
      )
    event.shaped(
        Item.of('kubejs:gemstone_hoe', 1),
        [
          'GG',
          ' S',
          ' S'
        ],
        {
          G: '#forge:gem_tool_gems',
          S: 'minecraft:stick'
        }
      )
    event.shaped(
        Item.of('minecraft:cobblestone', 1),
        [
          'RR',
          'RR'
        ],
        {
          R: 'kubejs:rock'
        }
      )
    event.shaped(
        Item.of('minecraft:furnace', 1),
        [
          'SLS',
          'L L',
          'SLS'
        ],
        {
          S: '#forge:cobblestone',
          L: '#forge:raw_materials/lead'
        }
      )
    event.shaped(
        Item.of('minecraft:furnace', 1),
        [
          'SSS',
          'S S',
          'SSS'
        ],
        {
          S: '#forge:stone'
        }
      )

      ///================================= Juices =================================

      function JuiceRecipe(juice,fruit)
      {
        event.shapeless(juice,[fruit,fruit,'minecraft:glass_bottle','2x sugar','croptopia:food_press']).id(juice).keepIngredient('croptopia:food_press')
      }

      JuiceRecipe('croptopia:apple_juice','minecraft:apple')
      JuiceRecipe('croptopia:cranberry_juice','croptopia:cranberry')
      JuiceRecipe('croptopia:grape_juice','croptopia:grape')
      JuiceRecipe('croptopia:melon_juice','minecraft:melon_slice')
      JuiceRecipe('croptopia:orange_juice','croptopia:orange')
      JuiceRecipe('croptopia:pineapple_juice','croptopia:pineapple')
      JuiceRecipe('croptopia:saguaro_juice','croptopia:saguaro')
      JuiceRecipe('croptopia:tomato_juice','croptopia:tomato')

      ///================================= Mortar Recipes =================================
      event.shaped('kubejs:basic_mortar',
        [
          ' F ',
          'S S',
          ' S '
        ],
        {
          S: 'minecraft:stone',
          F: 'flint'
        }
      )

      event.shapeless('3x bone_meal', ['bone','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',2).id('minecraft:bone_meal')
      event.shapeless('9x bone_meal', ['bone_block','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',6).id('minecraft:bone_meal_from_bone_block')

      event.shapeless('4x glowstone_dust', ['minecraft:glowstone','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',4)
      event.shapeless('2x blaze_powder',['minecraft:blaze_rod','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',8).id('minecraft:blaze_powder')

      event.shapeless('2x thermal:basalz_powder',['thermal:basalz_rod','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',8).id('thermal:basalz_powder')
      event.shapeless('2x thermal:blizz_powder',['thermal:blizz_rod','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',8).id('thermal:blizz_powder')
      event.shapeless('2x thermal:blitz_powder',['thermal:blitz_rod','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',8).id('thermal:blitz_powder')

      event.shapeless('sugar', ['sugar_cane','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',1).id('minecraft:sugar_from_sugar_cane')
      event.shapeless('croptopia:flour', ['2x #croptopia:flourable','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',1).id('croptopia:flour')
      event.shapeless('croptopia:paprika', ['croptopia:chile_pepper','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',1).id('croptopia:paprika')

      

      //================================ Dough and Bread stuff =================================
      event.custom({
        'type': 'lychee:item_inside',
        'post': [
          {
            'type': 'drop_item',
            'item': 'croptopia:dough'
          }
        ],
        'item_in': [
          {
            'item': 'croptopia:flour'
          },
          {
            'item': 'croptopia:salt'
          },
          {
            'item': 'minecraft:egg'
          }
        ],
        'block_in': 'minecraft:water'
      }).id('croptopia:dough')
      
      event.shapeless('minecraft:cookie',['croptopia:dough','minecraft:cocoa_beans','minecraft:sugar']).id('minecraft:cookie')
      event.smelting('minecraft:bread','croptopia:dough').xp(0.35).id('minecraft:bread')
  })
  