Ponder.tags((event) => {
   
    event.createTag("kubejs:steaming", 'croptopia:steamed_rice', "In world steaming", "How to steam your food", [
        // some default items
        'croptopia:steamed_rice',
        'croptopia:steamed_broccoli',
        'croptopia:steamed_green_beans',
        'croptopia:steamed_crab',
        'croptopia:steamed_clams'
    ]);

    event.createTag("kubejs:oven",'minecraft:cookie',"Nature's aura Multiblocks","How to bake your food",
        [
            'croptopia:pecan_pie',
            'croptopia:banana_nut_bread',
            'minecraft:pumpkin_pie',
            'croptopia:apple_pie',
            'croptopia:cherry_pie',
            'croptopia:pecan_pie',
            'croptopia:rhubarb_pie',
            'minecraft:cookie',
            'croptopia:nutty_cookie',
            'croptopia:raisin_oatmeal_cookie'
        ]
    )
});

Ponder.registry((event) => {

    event.create(['croptopia:steamed_rice',
        'croptopia:steamed_broccoli',
        'croptopia:steamed_green_beans',
        'croptopia:steamed_crab',
        'croptopia:steamed_clams']).scene("steaming", "In world steaming","kubejs:steamer", (scene, util) => {
        
        scene.world.showSection([0, 0, 0, 3, 1, 3], Facing.DOWN);
        scene.idle(10);
        scene.world.showSection([1, 2, 1, 1, 2, 1], Facing.DOWN);
        scene.idle(10);
        scene.world.showSection([1, 3, 1, 1, 3, 1], Facing.DOWN);
        scene.idle(10);
        scene.text(40,"Throw ingredients on top of the trapdoor",[1.0,3.5,1.0])//.attachKeyFrame();
        scene.idle(50);
        scene.world.createItemEntity(util.vector.topOf(1.5, 3.5, 1.5), util.vector.of(0, 0, 0), "croptopia:steamed_rice");
        scene.world.setBlock([1, 1, 1],"kubejs:magma_block_on_cooldown",false)
        scene.text(40,"Steamer gets inactive for 5 seconds",[1.0,1.5,1.0])
    });

    event.create([
        'croptopia:pecan_pie',
        'croptopia:banana_nut_bread',
        'minecraft:pumpkin_pie',
        'croptopia:apple_pie',
        'croptopia:cherry_pie',
        'croptopia:pecan_pie',
        'croptopia:rhubarb_pie',
        'minecraft:cookie',
        'croptopia:nutty_cookie',
        'croptopia:raisin_oatmeal_cookie'
    ]).scene("oven", "In world cooking","kubejs:oven", (scene, util) => {

        scene.world.showSection([0, 0, 0, 3, 1, 3], Facing.DOWN);
        scene.idle(10);
        scene.world.showSection([1,2,1,1,2,1], Facing.DOWN);
        scene.idle(10);
        scene.world.showSection([0, 2, 0, 2, 2, 2], Facing.DOWN);
        scene.idle(10);
        scene.world.showSection([1, 3, 1, 1, 3, 1], Facing.DOWN);
        scene.idle(10);
        scene.world.showSection([1, 3, 0, 1, 3, 0], Facing.DOWN);
        scene.text(20,"Lever not necessary, but usefull",[1, 3.5, 0]);
        scene.idle(30);
        scene.world.replaceBlocks([1, 3, 0],"minecraft:air",false);
        /*scene.world.modifyBlock([1,3,0],(curState)=> curState.with("powered","true"),false);
        scene.idle(1);*/
        scene.world.modifyBlock([1,3,1],(curState)=> curState.with("open","true"),false);
        scene.text(30,"Drop ingredients inside the oven",[1, 3, 1]);
        scene.idle(35);
        scene.text(30,"Close the trapdoor to start cooking",[1, 3, 1]);
        scene.idle(30);
        /*scene.world.modifyBlock([1,3,0],(curState)=> curState.with("powered","false").with("face","floor"),false);
        scene.idle(1);*/
        scene.world.modifyBlock([1,3,1],(curState)=> curState.with("open","false"),false);
        scene.idle(5);
        scene.world.setBlock([1, 1, 1],"kubejs:magma_block_on_cooldown",false)
        scene.text(40,"Oven gets inactive for 5 seconds after succesful baking",[1.0,1.5,1.0])

    });

    

});
