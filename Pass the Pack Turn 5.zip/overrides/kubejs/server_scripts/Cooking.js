ServerEvents.recipes(event => {
    

      ///================================= Juices =================================

      function JuiceRecipe(juice,fruit)
      {
        event.shapeless(juice,[fruit,fruit,'minecraft:glass_bottle','2x sugar','croptopia:food_press']).id(juice).keepIngredient('croptopia:food_press')
      }

      JuiceRecipe('croptopia:apple_juice','minecraft:apple')
      JuiceRecipe('croptopia:cranberry_juice','croptopia:cranberry')
      JuiceRecipe('croptopia:grape_juice','croptopia:grape')
      JuiceRecipe('croptopia:melon_juice','minecraft:melon_slice')
      JuiceRecipe('croptopia:orange_juice','croptopia:orange')
      JuiceRecipe('croptopia:pineapple_juice','croptopia:pineapple')
      JuiceRecipe('croptopia:saguaro_juice','croptopia:saguaro')
      JuiceRecipe('croptopia:tomato_juice','croptopia:tomato')

      ///================================= Mortar Recipes =================================

      event.shapeless('sugar', ['sugar_cane','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',1).id('minecraft:sugar_from_sugar_cane')
      event.shapeless('croptopia:flour', ['2x #croptopia:flourable','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',1).id('croptopia:flour')
      event.shapeless('croptopia:paprika', ['croptopia:chile_pepper','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',1).id('croptopia:paprika')

      //================================ Cooking stuff =================================

      event.custom({
        'type': 'lychee:item_inside',
        'post': [
          {
            'type': 'drop_item',
            'item': 'croptopia:dough'
          }
        ],
        'item_in': [
          {
            'item': 'croptopia:flour'
          },
          {
            'item': 'croptopia:salt'
          },
          {
            'item': 'minecraft:egg'
          }
        ],
        'block_in': 'minecraft:water'
      }).id('croptopia:dough')// Dropping items in water result in dropping dough
      //================================= Baking in World ==================================

      function Baking(result, amount, ingredients, recipeId) {
        const contextualConditions = [
            { "type": "execute", "command": 'execute if block ~ ~1 ~ #kubejs:cooking_trapdoors[open=false,half=bottom]', "hide": true },
            { "type": "execute", "command": 'execute if block ~ ~-1 ~ minecraft:magma_block', "hide": true },
            { "type": "execute", "command": 'execute if block ~ ~ ~1 #kubejs:oven_blocks', "hide": true },
            { "type": "execute", "command": 'execute if block ~1 ~ ~ #kubejs:oven_blocks', "hide": true },
            { "type": "execute", "command": 'execute if block ~ ~ ~-1 #kubejs:oven_blocks', "hide": true },
            { "type": "execute", "command": 'execute if block ~-1 ~ ~ #kubejs:oven_blocks', "hide": true }
        ];
    
        const itemInputs = ingredients.map(function(ingredient) {
          var obj = {};
          obj[ingredient.type] = ingredient.name;
          return obj;
        });
    
        event.custom({
            'type': 'lychee:item_inside',
            "hide_in_viewer": true,
            "contextual": {
                "type": "and",
                "contextual": contextualConditions
            },
            'post': [
                {
                    'type': 'drop_item',
                    "count": amount,
                    'item': result
                },
                {
                  "type": "execute",
                  "command": 'playsound minecraft:block.lava.extinguish neutral @p' 
                },
                {
                  "type": "place",
                  "offsetY": -1,
                  "block": "kubejs:magma_block_on_cooldown"
                },
                {
                  "type": "delay", // 5 second delay before the "oven" is ready again
                  "s": 5
                },
                {
                  "type": "execute",
                  "command": 'playsound minecraft:block.blastfurnace.fire_crackle neutral @p'  
                },
                {
                  "type": "place",
                  "offsetY": -1,
                  "block": "minecraft:magma_block"
                }

            ],
            'item_in': itemInputs,
            'block_in': {
              "tag": "kubejs:oven_pressure_plates"
            }
        }).id(recipeId);
    
        // Second registration for JEI display
        event.custom({
            "type": "lychee:item_inside",
            "ghost": true,
            "comment": "Needs iron trapdoor above, magma block below and mud bricks around to work",
            'item_in': itemInputs,
            "block_in": {
              "tag": "kubejs:oven_pressure_plates"
            },
            "post": [
                {
                    "type": "drop_item",
                    "count": amount,
                    "item": result
                },
            ]
        })
    }
    
    // Example usage with cleaner parameter structure
    Baking('croptopia:banana_nut_bread',1 ,[
        { type: 'item', name: 'croptopia:dough' },
        { type: 'item', name: 'croptopia:banana' },
        { type: 'tag', name: 'forge:nuts' }
    ],'croptopia:banana_nut_bread');

    Baking('minecraft:pumpkin_pie',1 ,[
        { type: 'item', name: 'croptopia:dough' },
        { type: 'item', name: 'minecraft:pumpkin' },
        { type: 'item', name: 'minecraft:sugar' }
      ],'minecraft:pumpkin_pie');
    
    Baking('croptopia:apple_pie',1 ,[
        { type: 'item', name: 'croptopia:dough' },
        { type: 'item', name: 'minecraft:apple' },
        { type: 'item', name: 'minecraft:sugar' }
      ],'croptopia:apple_pie');

    Baking('croptopia:cherry_pie',1 ,[
        { type: 'item', name: 'croptopia:dough' },
        { type: 'item', name: 'croptopia:cherry' },
        { type: 'item', name: 'croptopia:cherry' },
        { type: 'item', name: 'minecraft:sugar' }
      ],'croptopia:cherry_pie');

    Baking('croptopia:pecan_pie',1 ,[
        { type: 'item', name: 'croptopia:dough' },
        { type: 'item', name: 'croptopia:pecan' },
        { type: 'item', name: 'minecraft:sugar' }
    ],'croptopia:pecan_pie');

    Baking('croptopia:rhubarb_pie',1 ,[
        { type: 'item', name: 'croptopia:dough' },
        { type: 'item', name: 'croptopia:rhubarb' },
        { type: 'item', name: 'minecraft:sugar' }
    ],'croptopia:rhubarb_pie');

    Baking('minecraft:cookie',3,[
        { type: 'item', name: 'croptopia:dough' },
        { type: 'item', name: 'minecraft:sugar' },
        { type: 'item', name: 'minecraft:cocoa_beans' }
    ],'minecraft:cookie');

    Baking('croptopia:nutty_cookie',5,[
        { type: 'item', name: 'croptopia:dough' },
        { type: 'item', name: 'minecraft:sugar' },
        { type: 'item', name: 'minecraft:cocoa_beans' },
        { type: 'tag', name: 'forge:nuts' }
    ],'croptopia:nutty_cookie');

    Baking('croptopia:raisin_oatmeal_cookie',8,[
        { type: 'item', name: 'croptopia:dough' },
        { type: 'item', name: 'minecraft:sugar' },
        { type: 'item', name: 'minecraft:cocoa_beans' },
        { type: 'item', name: 'croptopia:raisins' },
        { type: 'item', name: 'croptopia:oat' }
    ],'croptopia:raisin_oatmeal_cookie');
   


    // ================================== Steaming in world ==================================

      function Steaming(result,ingredients,recipeid)
      {

        const contextualConditions = [
          { "type": "execute", "command": 'execute if block ~ ~-1 ~ minecraft:bubble_column', "hide": true },
          { "type": "execute", "command": 'execute if block ~ ~-2 ~ minecraft:magma_block', "hide": true }
        ]

        const itemInputs = ingredients.map(function(ingredient) {
          var obj = {};
          obj[ingredient.type] = ingredient.name;
          return obj;
        });

        event.custom({
          'type': 'lychee:item_inside',
          "hide_in_viewer": true,// Hidden in JEI because its hard to read
          'item_in': itemInputs,
          "contextual": {
            "type": "and",
            "contextual": contextualConditions
          },
          'post': [
            {
              'type': 'drop_item',
              'item': result
            },
            {
              "type": "execute",
              "command": 'playsound minecraft:block.lava.extinguish neutral @p' 
            },
            {
              "type": "place",
              "offsetY": -2,
              "block": "kubejs:magma_block_on_cooldown"
            },
            {
              "type": "delay", // 5 second delay before the "Steamer" is ready again
              "s": 5
            },
            {
              "type": "execute",
              "command": 'playsound minecraft:block.blastfurnace.fire_crackle neutral @p'  
            },
            {
              "type": "place",
              "offsetY": -2,
              "block": "minecraft:magma_block"
            }
          ],
          'block_in': {
            "tag": "kubejs:cooking_trapdoors"
          }
        }).id(recipeid)
  
        event.custom({
          "type": "lychee:item_inside",
          "ghost": true,
          "comment": "Needs water below trapdoor and magma block below water to work",
          'item_in': itemInputs,
          "block_in": {
            "tag": "kubejs:cooking_trapdoors"
          },
          "post": [
            {
              "type": "drop_item",
              "item": result
            }
          ]
        })// Better JEI display, will probably replace it with ponderjs later
      }

      Steaming('croptopia:steamed_rice',[
        { type: 'item', name: 'croptopia:rice' },
        { type: 'item', name: 'croptopia:salt' },
        { type: 'item', name: 'minecraft:bowl' }
      ],'croptopia:steamed_rice')

      Steaming('croptopia:steamed_broccoli',[
        { type: 'item', name: 'croptopia:broccoli' },
        { type: 'item', name: 'croptopia:salt' },
        { type: 'item', name: 'minecraft:bowl' }
      ],'croptopia:shaped_steamed_broccoli')
      
      Steaming('croptopia:steamed_green_beans',[
        { type: 'item', name: 'croptopia:greenbean' },
        { type: 'item', name: 'croptopia:salt' },
        { type: 'item', name: 'minecraft:bowl' }
      ],'croptopia:shaped_steamed_green_beans')
      
      Steaming('croptopia:steamed_crab',[
        { type: 'item', name: 'croptopia:crab' },
        { type: 'item', name: 'croptopia:salt' },
        { type: 'item', name: 'croptopia:pepper' }
      ],'croptopia:steamed_crab')
      
      Steaming('croptopia:steamed_clams',[
        { type: 'item', name: 'croptopia:clam' },
        { type: 'item', name: 'croptopia:salt' },
        { type: 'item', name: 'croptopia:pepper' },
        { type: 'item', name: 'croptopia:garlic' },
        { type: 'item', name: 'croptopia:butter' }
      ],'croptopia:steamed_clams')


      //================================= Cooking in Furnace ==================================
      

      event.smelting('minecraft:bread','croptopia:dough').xp(0.35).id('minecraft:bread')
      event.smelting('croptopia:sunny_side_eggs','minecraft:egg').xp(0.35).id('croptopia:sunny_side_eggs')
  })
  