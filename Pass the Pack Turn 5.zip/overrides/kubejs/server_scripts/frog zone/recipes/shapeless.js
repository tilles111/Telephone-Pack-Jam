ServerEvents.recipes(event => {

    event.shapeless(Item.of('minecraft:fire_charge', 2), [
        'occultism:burnt_otherstone',
        'malum:arcane_charcoal_fragment',
        'malum:arcane_charcoal_fragment',
        'malum:arcane_charcoal_fragment',
        'malum:arcane_charcoal_fragment'
    ])
    // i might want to improve this recipe later
    // also make recipes for the other charges added by thermal
    // maybe do lychee for them?

    event.shapeless('minecraft:magma_block', [
        'occultism:otherstone',
        'malum:arcane_charcoal'
    ])
    // this one is thematic with the other one so if that one is changed this one should be too

})