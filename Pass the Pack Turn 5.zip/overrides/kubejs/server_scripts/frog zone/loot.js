LootJS.modifiers(event => {

    event.removeGlobalModifier(['sushigocrafting:grass_seeds'])

})