ServerEvents.tags('block', event => {

    // Lumberjack chops soulwood
    event.add('occultism:tree_soil', [
        'malum:blighted_soil',
        'malum:blighted_earth'
    ])

    

})