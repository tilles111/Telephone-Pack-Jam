ClientEvents.lang('en_us', event => {

    event.renameItem('architects_palette:sunmetal_brick', 'Sunmetal Ingot')
    
    event.renameBlock('architects_palette:calcite_bricks', 'Calcite Tiles')
    event.renameBlock('architects_palette:calcite_brick_slab', 'Calcite Tile Slab')
    event.renameBlock('architects_palette:calcite_brick_vertical_slab', 'Calcite Tile Vertical Slab')
    event.renameBlock('architects_palette:calcite_brick_stairs', 'Calcite Tile Stairs')
    event.renameBlock('architects_palette:calcite_brick_wall', 'Calcite Tile Wall')

    event.renameItem('sushigocrafting:cooked_rice', 'Sushi Rice')
    event.renameItem('sushigocrafting:soy_sauce', 'Sushi Soy Sauce')

    event.renameBlock('occultism:candle_white', 'Tallow Candle')

})