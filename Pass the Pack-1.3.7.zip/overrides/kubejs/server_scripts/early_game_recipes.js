ServerEvents.recipes(event => {
    event.remove({ output: 'minecraft:furnace' })
    event.remove({ output: 'quark:deepslate_furnace' })
    event.remove({ output: 'quark:blackstone_furnace' })
    event.shaped(
        Item.of('kubejs:flint_chisel', 1),
        [
          ' F',
          'S '
        ],
        {
          F: 'minecraft:flint',
          S: 'minecraft:stick'
        }
      )
    event.shaped(
        Item.of('kubejs:gemstone_sword', 1),
        [
          'G',
          'G',
          'S'
        ],
        {
          G: '#forge:gem_tool_gems',
          S: 'minecraft:stick'
        }
      )
    event.shaped(
        Item.of('kubejs:gemstone_pickaxe', 1),
        [
          'GGG',
          ' S ',
          ' S '
        ],
        {
          G: '#forge:gem_tool_gems',
          S: 'minecraft:stick'
        }
      )
    event.shaped(
        Item.of('kubejs:gemstone_shovel', 1),
        [
          'G',
          'S',
          'S'
        ],
        {
          G: '#forge:gem_tool_gems',
          S: 'minecraft:stick'
        }
      )
    event.shaped(
        Item.of('kubejs:gemstone_axe', 1),
        [
          'GG',
          'GS',
          ' S'
        ],
        {
          G: '#forge:gem_tool_gems',
          S: 'minecraft:stick'
        }
      )
    event.shaped(
        Item.of('kubejs:gemstone_hoe', 1),
        [
          'GG',
          ' S',
          ' S'
        ],
        {
          G: '#forge:gem_tool_gems',
          S: 'minecraft:stick'
        }
      )
    event.shaped(
        Item.of('minecraft:cobblestone', 1),
        [
          'RR',
          'RR'
        ],
        {
          R: 'kubejs:rock'
        }
      )
    event.shaped(
        Item.of('minecraft:furnace', 1),
        [
          'SLS',
          'L L',
          'SLS'
        ],
        {
          S: 'minecraft:cobblestone',
          L: '#forge:raw_materials/lead'
        }
      )
    event.shaped(
        Item.of('quark:deepslate_furnace', 1),
        [
          'SLS',
          'L L',
          'SLS'
        ],
        {
          S: 'minecraft:cobbled_deepslate',
          L: '#forge:raw_materials/lead'
        }
      )
    event.shaped(
        Item.of('quark:blackstone_furnace', 1),
        [
          'SLS',
          'L L',
          'SLS'
        ],
        {
          S: 'minecraft:blackstone',
          L: '#forge:raw_materials/lead'
        }
      )
    event.shaped(
        Item.of('minecraft:furnace', 1),
        [
          'SSS',
          'S S',
          'SSS'
        ],
        {
          S: 'minecraft:stone'
        }
      )
    event.shaped(
        Item.of('quark:deepslate_furnace', 1),
        [
          'SSS',
          'S S',
          'SSS'
        ],
        {
          S: 'minecraft:deepslate'
        }
      )



      ///================================= Mortar Recipes =================================
      event.shaped('kubejs:basic_mortar',
        [
          ' F ',
          'S S',
          ' S '
        ],
        {
          S: 'minecraft:stone',
          F: 'flint'
        }
      )

      event.shapeless('3x bone_meal', ['bone','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',2).id('minecraft:bone_meal')
      event.shapeless('9x bone_meal', ['bone_block','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',6).id('minecraft:bone_meal_from_bone_block')

      event.shapeless('4x glowstone_dust', ['minecraft:glowstone','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',4)
      event.shapeless('2x blaze_powder',['minecraft:blaze_rod','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',8).id('minecraft:blaze_powder')

      event.shapeless('2x thermal:basalz_powder',['thermal:basalz_rod','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',8).id('thermal:basalz_powder')
      event.shapeless('2x thermal:blizz_powder',['thermal:blizz_rod','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',8).id('thermal:blizz_powder')
      event.shapeless('2x thermal:blitz_powder',['thermal:blitz_rod','kubejs:basic_mortar']).damageIngredient('kubejs:basic_mortar',8).id('thermal:blitz_powder')

      
  })
  