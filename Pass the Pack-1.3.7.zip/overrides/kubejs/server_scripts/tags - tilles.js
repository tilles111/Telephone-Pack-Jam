ServerEvents.tags('item', event => {
  event.add('forge:gem_tool_gems', 'thermal:ruby')
  event.add('forge:gem_tool_gems', 'thermal:sapphire')
  event.add('forge:gem_tool_gems', 'minecraft:emerald')
})