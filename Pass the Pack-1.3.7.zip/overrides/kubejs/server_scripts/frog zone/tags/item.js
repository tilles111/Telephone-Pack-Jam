ServerEvents.tags('item', event => {

    // hi welcome to frog zone

    // just for fun, allows an early game defensive option
    event.add('supplementaries:throwable_bricks', [
        'kubejs:rock'
    ])
    event.remove('supplementaries:throwable_bricks', [
        'architects_palette:sunmetal_brick'
    ])


    // Chisels
    event.add('forge:tools/chisels', [
        'kubejs:flint_chisel',
        'kubejs:gemstone_chisel'
    ])

    // Soy
    event.add('forge:crops/soy_bean', [
        '#forge:crops/soybean'
    ])

})