ServerEvents.recipes(event => {

    // Lead Recipes for Iron stuff
    event.replaceInput({output: 'minecraft:hopper'}, '#forge:ingots/iron', ['#forge:ingots/iron', "#forge:ingots/lead"])
    event.replaceInput({output: 'minecraft:cauldron'}, '#forge:ingots/iron', ['#forge:ingots/iron', "#forge:ingots/lead"])
    event.replaceInput({output: 'minecraft:smithing_table'}, '#forge:ingots/iron', ['#forge:ingots/iron', "#forge:ingots/lead"])
    event.replaceInput({output: 'minecraft:anvil'}, '#forge:ingots/iron', ['#forge:ingots/iron', "#forge:ingots/lead"])
    event.replaceInput({output: 'minecraft:anvil'}, '#forge:storage_blocks/iron', ['#forge:storage_blocks/iron', "#forge:storage_blocks/lead"])
    event.replaceInput({output: 'minecraft:chain'}, '#forge:ingots/iron', ['#forge:ingots/iron', "#forge:ingots/lead"])
    event.replaceInput({output: 'minecraft:chain'}, '#forge:nuggets/iron', ['#forge:nuggets/iron', "#forge:nuggets/lead"])
    event.replaceInput({output: 'decorative_blocks:chain'}, '#forge:ingots/iron', ['#forge:ingots/iron', "#forge:ingots/lead"])
    event.replaceInput({output: 'decorative_blocks:chain'}, '#forge:nuggets/iron', ['#forge:nuggets/iron', "#forge:nuggets/lead"])
    event.replaceInput({output: 'architects_palette:plating_block'}, '#forge:ingots/iron', ['#forge:ingots/iron', "#forge:ingots/lead"])
    event.replaceInput({output: 'architects_palette:plating_block'}, '#forge:nuggets/iron', ['#forge:nuggets/iron', "#forge:nuggets/lead"])
    event.replaceInput({output: 'architects_palette:tread_plate'}, '#forge:nuggets/iron', ['#forge:nuggets/iron', "#forge:nuggets/lead"])
    // supplementaries cage?

    // Silver Recipes for Iron stuff
    event.replaceInput({output: 'supplementaries:goblet'}, '#forge:ingots/iron', ['#forge:ingots/iron', "#forge:ingots/silver"])
    event.replaceInput({output: 'supplementaries:goblet'}, '#forge:nuggets/iron', ['#forge:nuggets/iron', "#forge:nuggets/silver"])
    event.replaceInput({output: 'minecraft:bucket'}, '#forge:ingots/iron', ['#forge:ingots/iron', "#forge:ingots/silver"])


})