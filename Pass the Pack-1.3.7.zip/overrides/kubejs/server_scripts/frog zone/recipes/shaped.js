ServerEvents.recipes(event => {

    // Gemstone Chisel
    event.shaped('kubejs:gemstone_chisel', [
        ' A',
        'B '
    ], {
        A: '#forge:gem_tool_gems',
        B: '#forge:rods/wooden'
    })

    // New Scythe
    event.remove({id: 'malum:crude_scythe'})
    event.shaped('malum:crude_scythe', [
        'AAB',
        ' CA',
        'C  '
    ], {
        A: '#forge:ingots/silver',
        B: 'occultism:spirit_attuned_gem',
        C: '#forge:rods/wooden'
    })

    // New Butcher Knife
    event.remove({id: 'occultism:crafting/butcher_knife'})
    event.shaped('occultism:butcher_knife', [
        'AA',
        'AA',
        ' B'
    ], {
        A: '#forge:ingots/silver',
        B: '#forge:rods/wooden'
    })

    // Summoning Altar
    event.shaped('summoningrituals:altar', [
        'ABA',
        'CDC',
        ' E '
    ], {
        A: 'occultism:candle_white',
        B: '#malum:aspected_spirits',
        C: '#malum:runewood_planks',
        D: 'minecraft:red_wool',
        E: '#malum:runewood_logs'
    })
    // this recipe might be worth fixing

    // stupid detail that can probably wait
    event.remove({id: 'architects_palette:calcite_bricks'})
    event.shaped(Item.of('architects_palette:calcite_bricks'), [
        'AA',
        'AA'
    ], {
        A: 'quark:calcite_bricks'
    })
    // i think i have to do tuff, too, to be consistent
})