
global.Fruits = [
    'minecraft:apple',
    'minecraft:melon_slice',
    'minecraft:glow_berries',
    'minecraft:sweet_berries',
    'croptopia:pineapple',
    'croptopia:blackberry',
    'croptopia:cantaloupe',
    'croptopia:cranberry',
    'croptopia:currant',
    'croptopia:elderberry',
    'croptopia:grape',
    'croptopia:greenonion',
    'croptopia:honeydew',
    'croptopia:kiwi',
    'croptopia:raspberry',
    'croptopia:rhubarb',
    'croptopia:saguaro',
    'croptopia:strawberry',
    'croptopia:tomatillo',
    'croptopia:apricot',
    'croptopia:avocado',
    'croptopia:banana',
    'croptopia:cherry',
    'croptopia:coconut',
    'croptopia:date',
    'croptopia:dragonfruit',
    'croptopia:fig',
    'croptopia:grapefruit',
    'croptopia:kumquat',
    'croptopia:lemon',
    'croptopia:lime',
    'croptopia:mango',
    'croptopia:nectarine',
    'croptopia:orange',
    'croptopia:peach',
    'croptopia:pear',
    'croptopia:persimmon',
    'croptopia:plum',
    'croptopia:starfruit',  
]// Fruits give more hunger than veggies but less saturation

global.Grains = [
    'croptopia:oat',
    'croptopia:rice',
    'croptopia:barley',
    'croptopia:corn',
    'croptopia:coffee_beans',
]// Eww dont eat those raw wtf

global.Nuts = [
    'croptopia:almond',
    'croptopia:cashew',
    'croptopia:walnut',
    'croptopia:peanut',
    'croptopia:pecan',
]// Superior to fruits and veggies

global.Veggies = [
    'minecraft:carrot',
    'minecraft:potato',
    'minecraft:beetroot',
    'croptopia:tomato',
    'croptopia:artichoke',
    'croptopia:asparagus',
    'croptopia:basil',
    'croptopia:bellpepper',
    'croptopia:blackbean',
    'croptopia:broccoli',
    'croptopia:cabbage',
    'croptopia:cauliflower',
    'croptopia:celery',
    'croptopia:chile_pepper',
    'croptopia:cucumber',
    'croptopia:garlic',
    'croptopia:ginger',
    'croptopia:greenbean',
    'croptopia:kale',
    'croptopia:leek',
    'croptopia:lettuce',
    'croptopia:olive',
    'croptopia:onion',
    'croptopia:raddish',
    'croptopia:rutabaga',
    'croptopia:squash',
    'croptopia:spinach',
    'croptopia:sweetpotato',
    'croptopia:tomato',
    'croptopia:turnip',
    'croptopia:yam',
    'croptopia:zucchini',
    'croptopia:nutmeg'
]// Most Basic Food

global.RawMeat = [
    'minecraft:rabbit',
    'minecraft:beef',
    'minecraft:porkchop',
    'minecraft:chicken',
    'minecraft:mutton',
    'minecraft:cod',
    'minecraft:salmon',
    'minecraft:tropical_fish',
    'minecraft:pufferfish',
    'croptopia:anchovy',
    'croptopia:calamari',
    'croptopia:clam',
    'croptopia:crab',
    'croptopia:glowing_calamari',
    'croptopia:oyster',
    'croptopia:shrimp',
    'croptopia:roe',
    'croptopia:tuna',
    'croptopia:bacon',
    'croptopia:ground_pork',
    'croptopia:frog_legs'
    ]// Dont Eat Those raw either

global.CookedMeat = [
    'minecraft:cooked_rabbit',
    'minecraft:cooked_beef',
    'minecraft:cooked_porkchop',
    'minecraft:cooked_chicken',
    'minecraft:cooked_mutton',
    'minecraft:cooked_cod',
    'minecraft:cooked_salmon',
    'croptopia:cooked_anchovy',
    'croptopia:cooked_calamari',
    'croptopia:cooked_bacon',
    'croptopia:cooked_shrimp',
    'croptopia:cooked_tuna',
    'croptopia:sunny_side_eggs',  
]// Slightly Better than nuts

global.Juices = [
    'croptopia:apple_juice',
    'croptopia:melon_juice',
    'croptopia:tomato_juice',
    'croptopia:cranberry_juice',
    'croptopia:grape_juice',
    'croptopia:orange_juice',
    'croptopia:saguaro_juice',
    'croptopia:pineapple_juice',

]// Very easy to make but you cant make it from the start (Requires a press)

 global.BasicSteamed = [
    'croptopia:steamed_rice',
    'croptopia:steamed_broccoli',
    'croptopia:steamed_green_beans',
 ]// Requiers Multiblock to make

 global.BakeGoods = [
    'minecraft:pumpkin_pie',
    'croptopia:apple_pie',
    'croptopia:pecan_pie',
    'croptopia:cherry_pie',
    'croptopia:rhubarb_pie',
    'croptopia:banana_nut_bread'
 ]//Requires Oven Multiblock to make

 global.Cookies = [
    'minecraft:cookie',
    'croptopia:nutty_cookie',
    'croptopia:raisin_oatmeal_cookie'
]// Similiar to Baked goods but worse and craft more at a time and they are fast to eat

global.BasicCooking =[
    'minecraft:bread',
    'minecraft:baked_potato',
    'croptopia:baked_yam',
    'croptopia:popcorn',
    'croptopia:toast',
    'croptopia:baked_sweet_potato',
    'croptopia:baked_beans',
    'croptopia:roasted_nuts',
]// Baked Veggies etc. Slightly worse than cooked meat

ItemEvents.modification(event => {
    
    global.CookedMeat.forEach(id => {
        event.modify(id, item => {
            item.foodProperties = food => {
                food.hunger(3)
                food.saturation(0.4)
            }
          })
    });

    global.Juices.forEach(id => {
        event.modify(id, item => {
            item.foodProperties = food => {
                food.hunger(5)
                food.saturation(0.4)
            }
          })
    });

    global.BasicSteamed.forEach(id => {
    event.modify(id, item => {
        item.foodProperties = food => {
            food.hunger(6)
            food.saturation(0.3)
        }
    })
    });

    event.modify('croptopia:steamed_crab', item => {
        item.foodProperties = food => {
            food.hunger(7)
            food.saturation(0.4)
        }
    })

    event.modify('croptopia:steamed_clams', item => {
        item.foodProperties = food => {
            food.hunger(10)
            food.saturation(0.4)
        }
    })

    global.BasicCooking.forEach(id => {
        event.modify(id, item => {
            item.foodProperties = food => {
                food.hunger(3)
                food.saturation(0.30)
            }
          })
    });

    global.Nuts.forEach(id => {
        event.modify(id, item => {
            item.foodProperties = food => {
                food.hunger(3)
                food.saturation(0.35)
            }
          })
    });

    global.RawMeat.forEach(id => {
        event.modify(id, item => {
            item.foodProperties = food => {
                food.hunger(1)
                food.saturation(0.2)
                food.effect('minecraft:hunger', 600, 0, 0.4)
            }
          })
    });

    global.Fruits.forEach(id => {
        event.modify(id, item => {
            item.foodProperties = food => {
                food.hunger(2)
                food.saturation(0.1)
                food.fastToEat(true)
            }
          })
    });

    global.Veggies.forEach(id => {
        event.modify(id, item => {
            item.foodProperties = food => {
                food.hunger(1.5)
                food.saturation(0.4)
            }
          })
    });

    global.Grains.forEach(id => {
        event.modify(id, item => {
            item.foodProperties = null 
          })
    });

    global.Cookies.forEach(id => {
        event.modify(id, item => {
            item.foodProperties = food => {
                food.hunger(4)
                food.saturation(0.4)
                food.fastToEat(true)
            }
          })
    });

    global.BakeGoods.forEach(id => {
        event.modify(id, item => {
            item.foodProperties = food => {
                food.hunger(7)
                food.saturation(0.4)
            }
          })
    });
})
