   // This list (itemsToRemove) can be used to remove items from the game. 

   // Currently, it removes items from JEI, removes all related recipes for that item, 
   // and untags those items (untagging items is important to not break stuff when removing output recipes for that item)

   // It relies on the other "nuke" files in various KubeJS script folders to function properly.
   global.itemsToRemove = [   
   
   'minecraft:wooden_sword',
   'minecraft:wooden_pickaxe',
   'minecraft:wooden_shovel',
   'minecraft:wooden_axe',
   'minecraft:wooden_hoe',
   'minecraft:stone_sword',
   'minecraft:stone_pickaxe',
   'minecraft:stone_shovel',
   'minecraft:stone_axe',
   'minecraft:stone_hoe'

  ] 