ServerEvents.recipes(event => {
    event.remove({ output: 'minecraft:furnace' })
    event.shaped(
        Item.of('kubejs:chisel', 1),
        [
          ' F',
          'S '
        ],
        {
          F: 'minecraft:flint',
          S: 'minecraft:stick'
        }
      )
    event.shaped(
        Item.of('kubejs:gemstone_sword', 1),
        [
          'G',
          'G',
          'S'
        ],
        {
          G: '#forge:gem_tool_gems',
          S: 'minecraft:stick'
        }
      )
    event.shaped(
        Item.of('kubejs:gemstone_pickaxe', 1),
        [
          'GGG',
          ' S ',
          ' S '
        ],
        {
          G: '#forge:gem_tool_gems',
          S: 'minecraft:stick'
        }
      )
    event.shaped(
        Item.of('kubejs:gemstone_shovel', 1),
        [
          'G',
          'S',
          'S'
        ],
        {
          G: '#forge:gem_tool_gems',
          S: 'minecraft:stick'
        }
      )
    event.shaped(
        Item.of('kubejs:gemstone_axe', 1),
        [
          'GG',
          'GS',
          ' S'
        ],
        {
          G: '#forge:gem_tool_gems',
          S: 'minecraft:stick'
        }
      )
    event.shaped(
        Item.of('kubejs:gemstone_hoe', 1),
        [
          'GG',
          ' S',
          ' S'
        ],
        {
          G: '#forge:gem_tool_gems',
          S: 'minecraft:stick'
        }
      )
    event.shaped(
        Item.of('minecraft:cobblestone', 1),
        [
          'RR',
          'RR'
        ],
        {
          R: 'kubejs:rock'
        }
      )
    event.shaped(
        Item.of('minecraft:furnace', 1),
        [
          'SLS',
          'L L',
          'SLS'
        ],
        {
          S: '#forge:cobblestone',
          L: '#forge:raw_materials/lead'
        }
      )
    event.shaped(
        Item.of('minecraft:furnace', 1),
        [
          'SSS',
          'S S',
          'SSS'
        ],
        {
          S: '#forge:stone'
        }
      )
  })
  